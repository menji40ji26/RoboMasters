
#ifndef __BSP_CAN_H
#define __BSP_CAN_H


#include "stm32f4xx.h"


void BSP_CAN_InitConfig(void);


#endif
