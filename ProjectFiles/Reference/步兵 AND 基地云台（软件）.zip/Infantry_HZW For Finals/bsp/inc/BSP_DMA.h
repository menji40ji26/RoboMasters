#ifndef __BSP_DMA_H
#define __BSP_DMA_H


#include "stm32f4xx.h"


void BSP_DMA_InitConfig(void);


#endif
