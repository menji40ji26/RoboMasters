#ifndef __BSP_NVIC_H
#define __BSP_NVIC_H


#include "stm32f4xx.h"


void BSP_NVIC_InitConfig(void);


#endif
