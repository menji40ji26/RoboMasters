#ifndef __BSP_TIM_H
#define __BSP_TIM_H


#include "stm32f4xx.h"


void BSP_TIM_InitConfig(void);


#endif
