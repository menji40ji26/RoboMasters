#ifndef __BSP_UART_H
#define __BSP_UART_H


#include "stm32f4xx.h"


void BSP_UART_InitConfig(void);


#endif
