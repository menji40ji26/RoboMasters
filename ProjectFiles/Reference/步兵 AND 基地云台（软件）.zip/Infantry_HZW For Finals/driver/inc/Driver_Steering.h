#ifndef __DRIVER_STEERING_H
#define __DRIVER_STEERING_H


#include "stm32f4xx.h"



void Steering_InitConfig(void);
void Steering_Control(uint8_t status);


#endif
