
#ifndef __TASK_CONTROL_H
#define __TASK_CONTROL_H


#include "stm32f4xx.h"
#include "OSinclude.h"


void Task_Control(void *Parameters);


#endif


