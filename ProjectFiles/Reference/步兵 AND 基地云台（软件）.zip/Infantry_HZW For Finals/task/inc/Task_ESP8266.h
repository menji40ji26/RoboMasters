#ifndef __TASK_ESP8266_H
#define __TASK_ESP8266_H


#include "stm32f4xx.h"
#include "OSinclude.h"




void Task_SetupConnection(void *Parameters);




#endif
