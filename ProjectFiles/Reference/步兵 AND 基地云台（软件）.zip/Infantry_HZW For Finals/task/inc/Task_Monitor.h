
#ifndef __TASK_MONITOR_H
#define __TASK_MONITOR_H


#include "stm32f4xx.h"
#include "OSinclude.h"


void Task_Monitor(void *Parameters);


#endif
