
#ifndef __TASK_SYSTEMINITCONFIG_H
#define __TASK_SYSTEMINITCONFIG_H


#include "stm32f4xx.h"
#include "OSinclude.h"


void Task_SysInitConfig(void *Parameters);


#endif
