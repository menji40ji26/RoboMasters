#ifndef __OSINCLUDE_H
#define __OSINCLUDE_H


#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "queue.h"
#include "semphr.h"
#include "event_groups.h"


#endif
